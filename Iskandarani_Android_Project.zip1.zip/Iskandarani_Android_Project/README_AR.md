# إسكندراني

نسخة أولية من تطبيق Android لعرض المحلات والمنتجات والعروض من Supabase.

## قبل التشغيل
افتح:
`app/build.gradle.kts`

وابحث عن:
`SUPABASE_URL`
و
`SUPABASE_ANON_KEY`

ضع رابط مشروع Supabase ومفتاح `anon` الخاص بالمشروع بدل القيم الفارغة.

مثال:
buildConfigField("String", "SUPABASE_URL", "\"https://YOUR_PROJECT.supabase.co\"")
buildConfigField("String", "SUPABASE_ANON_KEY", "\"YOUR_ANON_KEY\"")

لا تضع Service Role Key داخل تطبيق Android.

## الموجود حاليًا
- شاشة رئيسية عربية.
- شاشة المحلات.
- شاشة العروض.
- اتصال هاتفي بالمحل.
- فتح واتساب.
- قراءة shops/products/offers من Supabase REST.
- بيانات تجريبية يمكن استخدامها للاختبار.

## الخطوة التالية
إضافة:
- شاشة تفاصيل المحل.
- قائمة منتجات لكل محل.
- تسجيل/تسجيل دخول.
- صور من Supabase Storage.
- بحث وفلاتر.
- لوحة تحكم لإدارة المحلات.
