package com.iskandarani.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL

data class Shop(
    val id: Long,
    val name: String,
    val category: String,
    val area: String,
    val description: String,
    val phone: String,
    val whatsapp: String
)

data class Product(
    val id: Long,
    val shopId: Long,
    val name: String,
    val description: String,
    val price: Double,
    val discount: Double
)

data class Offer(
    val id: Long,
    val shopId: Long,
    val title: String,
    val description: String,
    val discount: Double
)

object SupabaseRepository {
    private const val BASE_URL = BuildConfig.SUPABASE_URL
    private const val KEY = BuildConfig.SUPABASE_ANON_KEY

    private fun request(table: String): JSONArray {
        if (BASE_URL.isBlank() || KEY.isBlank()) return JSONArray()
        val url = URL("$BASE_URL/rest/v1/$table?select=*")
        val conn = url.openConnection() as HttpURLConnection
        conn.requestMethod = "GET"
        conn.setRequestProperty("apikey", KEY)
        conn.setRequestProperty("Authorization", "Bearer $KEY")
        conn.setRequestProperty("Accept", "application/json")
        return try {
            JSONArray(conn.inputStream.bufferedReader().use { it.readText() })
        } finally {
            conn.disconnect()
        }
    }

    suspend fun shops(): List<Shop> = withContext(Dispatchers.IO) {
        runCatching {
            val a = request("shops")
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                Shop(
                    o.getLong("id"), o.getString("name"), o.getString("category"),
                    o.optString("area"), o.optString("description"),
                    o.optString("phone"), o.optString("whatsapp")
                )
            }
        }.getOrDefault(emptyList())
    }

    suspend fun products(): List<Product> = withContext(Dispatchers.IO) {
        runCatching {
            val a = request("products")
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                Product(
                    o.getLong("id"), o.optLong("shop_id"),
                    o.getString("name"), o.optString("description"),
                    o.optDouble("price", 0.0), o.optDouble("discount", 0.0)
                )
            }
        }.getOrDefault(emptyList())
    }

    suspend fun offers(): List<Offer> = withContext(Dispatchers.IO) {
        runCatching {
            val a = request("offers")
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                Offer(
                    o.getLong("id"), o.optLong("shop_id"),
                    o.getString("title"), o.optString("description"),
                    o.optDouble("discount", 0.0)
                )
            }
        }.getOrDefault(emptyList())
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { IskandaraniApp() }
    }
}

@Composable
fun IskandaraniApp() {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Color(0xFF0077B6),
            secondary = Color(0xFF00B4D8),
            background = Color(0xFFF7FAFC)
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize()) {
            AppShell()
        }
    }
}

@Composable
fun AppShell() {
    var tab by remember { mutableIntStateOf(0) }
    val tabs = listOf("الرئيسية", "المحلات", "العروض")
    Scaffold(
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { index, title ->
                    NavigationBarItem(
                        selected = tab == index,
                        onClick = { tab = index },
                        icon = {
                            Icon(
                                when (index) {
                                    0 -> Icons.Default.Home
                                    1 -> Icons.Default.Store
                                    else -> Icons.Default.LocalOffer
                                },
                                contentDescription = title
                            )
                        },
                        label = { Text(title) }
                    )
                }
            }
        }
    ) { padding ->
        when (tab) {
            0 -> HomeScreen(Modifier.padding(padding))
            1 -> ShopsScreen(Modifier.padding(padding))
            else -> OffersScreen(Modifier.padding(padding))
        }
    }
}

@Composable
fun HomeScreen(modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.fillMaxSize().padding(20.dp),
        horizontalAlignment = Alignment.End
    ) {
        Text("إسكندراني", fontSize = 32.sp, fontWeight = FontWeight.Bold)
        Text("كل اللي محتاجه من محلات إسكندرية", color = Color.Gray)
        Spacer(Modifier.height(20.dp))
        SearchBox()
        Spacer(Modifier.height(18.dp))
        Text("الأقسام", fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            CategoryCard("مطاعم", Icons.Default.Restaurant)
            CategoryCard("ملابس", Icons.Default.Checkroom)
            CategoryCard("إلكترونيات", Icons.Default.Devices)
        }
        Spacer(Modifier.height(24.dp))
        Text("ابدأ اكتشاف المحلات والعروض القريبة منك.", fontSize = 17.sp)
    }
}

@Composable
fun SearchBox() {
    var text by remember { mutableStateOf("") }
    OutlinedTextField(
        value = text,
        onValueChange = { text = it },
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        placeholder = { Text("ابحث عن محل أو منتج...") },
        leadingIcon = { Icon(Icons.Default.Search, null) },
        shape = RoundedCornerShape(16.dp)
    )
}

@Composable
fun CategoryCard(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Card(
        modifier = Modifier.weight(1f).height(100.dp),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(icon, null)
            Spacer(Modifier.height(6.dp))
            Text(title, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun ShopsScreen(modifier: Modifier = Modifier) {
    var shops by remember { mutableStateOf<List<Shop>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) {
        shops = SupabaseRepository.shops()
        loading = false
    }
    Column(modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.End) {
        Text("المحلات", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        if (loading) {
            CircularProgressIndicator()
        } else if (shops.isEmpty()) {
            Text("لم يتم تحميل المحلات. أضف بيانات Supabase داخل BuildConfig أولًا.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(shops) { ShopCard(it) }
            }
        }
    }
}

@Composable
fun ShopCard(shop: Shop) {
    val context = LocalContext.current
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.End) {
            Text(shop.name, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text("${shop.category} • ${shop.area}", color = Color.Gray)
            if (shop.description.isNotBlank()) {
                Spacer(Modifier.height(5.dp))
                Text(shop.description)
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (shop.phone.isNotBlank()) {
                    OutlinedButton(onClick = {
                        context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${shop.phone}")))
                    }) {
                        Icon(Icons.Default.Phone, null)
                        Spacer(Modifier.width(4.dp))
                        Text("اتصال")
                    }
                }
                if (shop.whatsapp.isNotBlank()) {
                    Button(onClick = {
                        context.startActivity(
                            Intent(
                                Intent.ACTION_VIEW,
                                Uri.parse("https://wa.me/${shop.whatsapp.filter { it.isDigit() }}")
                            )
                        )
                    }) {
                        Text("واتساب")
                    }
                }
            }
        }
    }
}

@Composable
fun OffersScreen(modifier: Modifier = Modifier) {
    var offers by remember { mutableStateOf<List<Offer>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) {
        offers = SupabaseRepository.offers()
        loading = false
    }
    Column(modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.End) {
        Text("العروض", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        if (loading) {
            CircularProgressIndicator()
        } else if (offers.isEmpty()) {
            Text("لا توجد عروض حاليًا.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(offers) { offer ->
                    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.End) {
                            Text(offer.title, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            Text(offer.description)
                            Spacer(Modifier.height(6.dp))
                            Text("خصم ${offer.discount}%")
                        }
                    }
                }
            }
        }
    }
}
